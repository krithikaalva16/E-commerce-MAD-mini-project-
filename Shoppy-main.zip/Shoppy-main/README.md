# Shoppy

# Description

This is an andriod application where users can shop cloths online.

This application allows users to see variety of cloths.

Users can see the pictures of the cloths, they can see the description of the product.

Users can see the rating of the product and can buy the cloths of their choice.

Users can add their desired cloths in the cart.

# Technologies Used : 

Language : Java

IDE : Android Studio


